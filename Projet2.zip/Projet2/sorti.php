<?php

require ("connect.php");
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sorti du Visiteur</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div class="Sorti Visiteur">
    <h1>Sorti Visiteur</h1>

    <form action="sorti.php" method="post">

        <div>
            <label for="id">ID</label>
            <input type="text" id="id" name="id" required>
        </div>
        <div>
            <button type="submit">Sortir</button>
        </div>
    </form>
</div>
</body>



<?php


if (isset($_POST['email'])) {


    visiteurs($_POST['id']);


}
/*-----------------------------------*/
/* Visiteurs   		      */
/*-----------------------------------*/
function visiteurs($id)
{
    $bdd = dbconnect();

    $heured= date("H:i");
    $dated = date("y-m-d");

    /* Query */
    $resquest = "UPDATE visiteurs SET Heure_depart = :heured where Id_visiteurs = :id";

    //e
    $returnInsert = $bdd->prepare($resquest);

    $returnInsert->execute(['heured' => $heured,
        ':id' => $id]);
    return $returnInsert;
}

?>
</body>
</html>
