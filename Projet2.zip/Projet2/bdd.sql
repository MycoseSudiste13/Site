Drop database if EXISTS musee;
CREATE Database musee;
use musee;


set autocommit=1;
SET SQL_SAFE_UPDATES = 0;
SET default_storage_engine=INNODB;

CREATE table ticket (

Type_de_ticket enum('P','T','D') ,
libelle enum ('Permanent','Temporaire','Deux'),
prix DECIMAL (10,2) ,
CONSTRAINT pk_Type_de_ticket PRIMARY KEY (Type_de_ticket)
);

INSERT into ticket(Type_de_ticket,libelle,prix)
Values('T','Temporaire',5.99),
('P','Permanent','9.99'),
('D','Deux','12.99');

select * from ticket;

DROP TABLE if exists exposition;

Create table exposition (
Id_exposition INT unsigned NOT NULL AUTO_INCREMENT,
Date_debut DATE ,
Date_fin DATE ,
Artiste VARCHAR(50) ,
Type_de_ticket enum('P','T') ,
CONSTRAINT fk_Type_de_ticket FOREIGN KEY (Type_de_ticket) REFERENCES ticket (Type_de_ticket),
CONSTRAINT pk_Id_exposition PRIMARY KEY (Id_exposition)
);
ALTER TABLE exposition
ADD column Affiche VARCHAR(50);
Insert into exposition (Date_debut,Date_fin,Artiste,Type_de_ticket,Affiche)
Values('2022-01-01','2022-02-01','Moliere','T','Moliere.jpg'),
('2022-01-01','2050-01-01','Picasso','P','Picasso.jpg'),
('2022-02-01','2022-04-01','Victor Hugo ','T','Victor.jpg');


Select * from exposition;

DROP TABLE IF EXISTS visiteurs;

 CREATE TABLE visiteurs ( 
Id_visiteurs  INT unsigned NOT NULL AUTO_INCREMENT,
Heure_arrivee TIME, 
email varchar(200),
Heure_depart TIME,
Code_postal INT,
_date Date,
Type_de_ticket ENUM ('P','T','D'),
CONSTRAINT fk_visiteurs FOREIGN KEY (Type_de_ticket) REFERENCES ticket (Type_de_ticket),
 constraint pk_Id_visiteurs primary key (Id_visiteurs)
);
select * from ticket;

Insert into visiteurs (Heure_arrivee,email,Heure_depart,Code_postal,_date, Type_de_ticket)
Values ('2022-03-22 15:10:56','enzo.esnault@gmail.com','2022-03-22 17:00:00','74940','2021-03-24','D'),
('2022-04-26 10:05:45','alexis.duboeuf@gmail.com','2022-04-26 12:05:59','74370','2021-05-12','T'),
('2022-05-16 16:16:16','antony.saulnier@gmail.com','2022-05-16 18:42:10','91000','2021-06-03','P');


Drop table if exists visiteurs_exposition;

CREATE TABLE visiteurs_exposition (
Id_visiteurs  INT unsigned ,
Id_exposition INT unsigned ,
Constraint fk_Id_exposition Foreign key (Id_exposition) References exposition (Id_exposition),
Constraint fk_Id_visiteurs Foreign key (Id_visiteurs) References visiteurs (Id_visiteurs),
Constraint pk_Id_visiteurs primary key (Id_visiteurs,Id_exposition)
);

select * from visiteurs;

UPDATE visiteurs SET Heure_depart = "20:00:00" where Id_visiteurs = 1;
			




