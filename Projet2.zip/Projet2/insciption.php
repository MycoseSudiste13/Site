<?php

require ("connect.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Musée</title>
    <link href="style.css" rel="stylesheet">
</head>

<body>
<div class="contactez-nous">
    <h1>Contactez-nous</h1>

    <form action="index.php" method="post">

        <div>
            <label for="email">Votre e-mail</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div>
            <label for="codepostal">Votre code postal</label>
            <input type="text" id="codepostal" name="codepostal" required>
        </div>
        <div>
            <label for="ticket">Quel est le type de ticket que vous voulez ?</label>
            <select name="ticket" id="ticket" required>
                <option value="" disabled selected hidden>Choisissez le type de ticket que vous voulez</option>
                <option value="permanent">Permanent</option>
                <option value="temporaire">Temporaire</option>
                <option value="deux">Les Deux</option>
            </select>
        </div>
        <div>
            <label for="dated">Date de debut</label>
            <input type="date" id="dated" name="dated">
        </div>
        <div>
            <label for="datef">Date de fin</label>
            <input type="date" id="datef" name="datef">
        </div>

        <div>
            <label for="artiste">Quel l'artiste vous voulez venir voir ?</label>
            <select name="artiste" id="artiste" required>
                <option value="" disabled selected hidden>Choisissez l'artiste que vous voulez voir </option>
                <option value="moliere">Moliere</option>
                <option value="picasso">Picasso</option>
                <option value="victorhugo">Victor Hugo</option>
            </select>
        </div>
        <h2>Molière</h2>
        <img src="image/Moliere.jpg">
        <h3>Picasso</h3>
        <img src="image/Picasso.jpg">
        <h4>Victor Hugo</h4>
        <img src="image/Victor.jpg">
        <div>
            <label for="message">Votre message</label>
            <textarea id="message" name="message" placeholder="Bonjour, je vous contacte car...."></textarea>
        </div>
        <div>
            <button type="submit">Envoyer mon message</button>
        </div>

    </form>
</div>

<?php
if (isset($_POST['email']) &&
    isset($_POST['codepostal']) &&
    isset($_POST['ticket']) &&
    isset($_POST['dated'])) {
    /* attention : isset() teste l'existence de la variable
    empty() teste si la variable est vide */



    visiteurs($_POST['email'], $_POST['codepostal'], $_POST['ticket']);


}
/*-----------------------------------*/
/* Visiteurs   		      */
/*-----------------------------------*/
function visiteurs($email,$codepostal, $ticket )
{
    $bdd = dbconnect();
    echo " Type de ticket " . $ticket . "<br>";
    if (!strcmp($ticket, "permanent")) {
        $ticket ="P";
    } else if (!strcmp($ticket, "temporaire")) {
        $ticket = "T";

    }else if (!strcmp($ticket, "deux")) {
        $ticket = "D";

    }
    $heurea= date("H:i");
    $dated = date("y-m-d");

    /* Query */
    $resquest = 'INSERT INTO visiteurs (email, Code_postal, Type_de_ticket, Heure_arrivee, _date) 
                VALUES (:email, :codepostal, :ticket, :heurea, :dated)';
    //echo 'requete insert = ' . $resquest;
    $returnInsert = $bdd->prepare($resquest);

    $returnInsert->execute(['email' => $email,
        'codepostal' => $codepostal,
        'ticket' => $ticket,
        'heurea' => $heurea,
        'dated' => $dated]);
    return $returnInsert;
}


?>
</body>
</html>

